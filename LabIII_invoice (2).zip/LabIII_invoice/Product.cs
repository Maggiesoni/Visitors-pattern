﻿using System;

namespace LabIII_invoice
{
    internal class Product
    {
        public string Title { get; set; }
        public decimal UnitPrice { get; set; }
         public Product Products { get; set; }

        public void Accept(IVisitor visitor)
        {
            if(Products != null)
            {
                visitor.VisitProduct(this);
                Products.Accept(visitor);

            }
        }
    }
}
